from core.blueprints.base_blueprint import BaseBlueprint

featuremodel_bp = BaseBlueprint('featuremodel', __name__, template_folder='templates')
