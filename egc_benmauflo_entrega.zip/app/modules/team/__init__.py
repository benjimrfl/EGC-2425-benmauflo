from core.blueprints.base_blueprint import BaseBlueprint

team_bp = BaseBlueprint('team', __name__, template_folder='templates')
